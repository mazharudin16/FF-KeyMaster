# FF KeyMaster
Native Android app (Kotlin + Jetpack Compose), package `com.ffkeymaster.app`, minSdk 26 (Android 8.0).

## Build
1. Android Studio Koala (2024.1.1) or newer -> File > Open -> select this folder.
2. Let Gradle sync (downloads Gradle 8.7 automatically), then Run on a device.

## First-run setup on the phone
1. Open the app -> Home -> ENABLE SERVICE -> turn on "FF KeyMaster" in Accessibility.
2. Connect a USB/Bluetooth keyboard. Allow battery exemption (recommended).
3. Add keys in Keys, place them in Layout, launch the game.

## Notes
- Taps are dispatched at fractions of the landscape screen, so layouts are resolution independent.
- Android allows limited simultaneous gestures from an accessibility service; very fast multi-key combos may drop.
