package com.ffkeymaster.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.ffkeymaster.app.data.AppData
import com.ffkeymaster.app.data.Repository
import com.ffkeymaster.app.util.SystemChecks
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(data: AppData) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val svc = remember(tick) { SystemChecks.accessibilityEnabled(ctx) }
    val batt = remember(tick) { SystemChecks.batteryUnrestricted(ctx) }
    val s = data.settings
    var tapMs by remember(s.tapMs) { mutableFloatStateOf(s.tapMs.toFloat()) }
    var disclosure by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenHeader("Settings", "Behaviour, permissions and app info.")

        Panel {
            Title("Mapper")
            SwitchRow("Enable key mapping", "Master switch for all mappings", s.mapperEnabled) { v ->
                Repository.updateSettings { it.copy(mapperEnabled = v) }
            }
            SwitchRow("Only active in Free Fire", "Keys behave normally in every other app", s.onlyInGame) { v ->
                Repository.updateSettings { it.copy(onlyInGame = v) }
            }
            SwitchRow("Vibrate on key press", "Short haptic feedback", s.vibrate) { v ->
                Repository.updateSettings { it.copy(vibrate = v) }
            }
            Text("Tap duration: ${tapMs.roundToInt()} ms", color = ColText)
            Slider(
                value = tapMs, onValueChange = { tapMs = it }, valueRange = 20f..200f,
                onValueChangeFinished = { Repository.updateSettings { it.copy(tapMs = tapMs.roundToInt()) } }
            )
        }

        Panel {
            Title("Permissions")
            StatusRow("Accessibility service", if (svc) "Enabled" else "Not enabled", svc, "Enable") { disclosure = true }
            StatusRow("Battery optimization", if (batt) "Unrestricted" else "Restricted — service may be stopped", batt, "Allow") {
                SystemChecks.requestBatteryExemption(ctx)
            }
            if (svc) OutlinedButton(onClick = { SystemChecks.openAccessibilitySettings(ctx) }) {
                Text("Open accessibility settings")
            }
        }

        Panel {
            Title("About")
            Sub("FF KeyMaster 1.0.0 • com.ffkeymaster.app")
            Sub("Maps a physical keyboard to touch input via Android's Accessibility API. Not affiliated with Garena. Check the game's rules before using input tools in competitive modes.")
            OutlinedButton(onClick = { confirmReset = true }) { Text("Reset all data", color = ColBad) }
        }
    }

    if (disclosure) DisclosureDialog({ disclosure = false }) {
        disclosure = false; SystemChecks.openAccessibilitySettings(ctx)
    }
    if (confirmReset) AlertDialog(
        onDismissRequest = { confirmReset = false },
        containerColor = ColCardHi,
        title = { Text("Reset everything?") },
        text = { Text("All profiles, mappings and settings will be replaced with defaults.") },
        confirmButton = { TextButton(onClick = { Repository.resetAll(); confirmReset = false }) { Text("Reset", color = ColBad) } },
        dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } }
    )
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = ColText)
            Sub(subtitle)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = ColAccent)
        )
    }
}
