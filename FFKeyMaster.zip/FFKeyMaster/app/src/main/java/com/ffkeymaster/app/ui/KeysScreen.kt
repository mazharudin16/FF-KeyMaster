package com.ffkeymaster.app.ui

import android.view.KeyEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ffkeymaster.app.data.*
import kotlin.math.roundToInt

@Composable
fun KeysScreen(data: AppData) {
    val profile = data.active
    var editing by remember { mutableStateOf<KeyMapping?>(null) }
    var creating by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { ScreenHeader("Key mapping", "Profile: ${profile.name} • ${profile.mappings.size} keys") }
            if (profile.mappings.isEmpty()) item { Panel { Sub("No mappings yet. Tap + to add your first key.") } }
            items(profile.mappings, key = { it.id }) { m ->
                MappingRow(m, onEdit = { editing = m }, onDelete = { Repository.deleteMapping(profile.id, m.id) })
            }
        }
        FloatingActionButton(
            onClick = { creating = true },
            containerColor = ColAccent, contentColor = Color.Black,
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)
        ) { Icon(Icons.Filled.Add, "Add mapping") }
    }

    if (creating) MappingDialog(null, { creating = false }) {
        Repository.saveMapping(profile.id, it); creating = false
    }
    editing?.let { e ->
        MappingDialog(e, { editing = null }) { Repository.saveMapping(profile.id, it); editing = null }
    }
}

@Composable
private fun MappingRow(m: KeyMapping, onEdit: () -> Unit, onDelete: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(ColCard).border(1.dp, ColLine, shape).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            Modifier.widthIn(min = 52.dp).clip(RoundedCornerShape(10.dp)).background(ColCardHi)
                .border(1.dp, ColAccent, RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) { Text(keyName(m.keyCode), color = ColAccent, fontWeight = FontWeight.Bold) }
        Column(Modifier.weight(1f)) {
            Text(m.name.ifBlank { "Unnamed" }, color = ColText, fontWeight = FontWeight.SemiBold)
            Sub("${m.type.name} • X ${(m.x * 100).roundToInt()}%  Y ${(m.y * 100).roundToInt()}%")
        }
        IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, "Edit", tint = ColMuted) }
        IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "Delete", tint = ColBad) }
    }
}

@Composable
private fun MappingDialog(initial: KeyMapping?, onDismiss: () -> Unit, onSave: (KeyMapping) -> Unit) {
    var keyCode by remember { mutableIntStateOf(initial?.keyCode ?: 0) }
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var x by remember { mutableFloatStateOf(initial?.x ?: 0.5f) }
    var y by remember { mutableFloatStateOf(initial?.y ?: 0.5f) }
    var type by remember { mutableStateOf(initial?.type ?: ActionType.TAP) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ColCardHi,
        title = { Text(if (initial == null) "New key mapping" else "Edit mapping") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val shape = RoundedCornerShape(12.dp)
                Box(
                    Modifier.fillMaxWidth().height(64.dp).clip(shape).background(ColBg)
                        .border(1.dp, ColAccent, shape)
                        .onPreviewKeyEvent { ev ->
                            if (ev.type == KeyEventType.KeyDown && ev.nativeKeyEvent.keyCode != KeyEvent.KEYCODE_BACK) {
                                keyCode = ev.nativeKeyEvent.keyCode; true
                            } else false
                        }
                        .focusRequester(focus)
                        .clickable { focus.requestFocus() },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (keyCode == 0) "Tap here, then press a key" else keyName(keyCode),
                        color = if (keyCode == 0) ColMuted else ColAccent, fontWeight = FontWeight.Bold
                    )
                }
                OutlinedTextField(name, { name = it }, label = { Text("Action name (e.g. Jump)") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionType.values().forEach {
                        FilterChip(selected = type == it, onClick = { type = it }, label = { Text(if (it == ActionType.TAP) "Tap" else "Hold") })
                    }
                }
                Sub(if (type == ActionType.TAP) "Taps once when the key is pressed." else "Keeps the touch down while the key is held.")
                Text("Screen X: ${(x * 100).roundToInt()}%", color = ColText)
                Slider(x, { x = it })
                Text("Screen Y: ${(y * 100).roundToInt()}%", color = ColText)
                Slider(y, { y = it })
            }
        },
        confirmButton = {
            TextButton(enabled = keyCode != 0, onClick = {
                onSave(
                    KeyMapping(
                        id = initial?.id ?: java.util.UUID.randomUUID().toString(),
                        keyCode = keyCode, name = name.trim(), x = x, y = y, type = type
                    )
                )
            }) { Text("Save", color = if (keyCode != 0) ColAccent else ColMuted) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
