package com.ffkeymaster.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier.fillMaxWidth().clip(shape).background(ColCard)
            .border(1.dp, ColLine, shape).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
fun Title(text: String) =
    Text(text, color = ColText, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

@Composable
fun Sub(text: String) =
    Text(text, color = ColMuted, style = MaterialTheme.typography.bodySmall)

@Composable
fun ScreenHeader(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, color = ColText, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.headlineSmall)
        Sub(subtitle)
    }
}

@Composable
fun StatusRow(title: String, subtitle: String, ok: Boolean, action: String?, onAction: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(if (ok) ColGood else ColBad))
        Column(Modifier.weight(1f)) {
            Text(title, color = ColText, fontWeight = FontWeight.SemiBold)
            Sub(subtitle)
        }
        if (!ok && action != null) {
            OutlinedButton(onClick = onAction, border = androidx.compose.foundation.BorderStroke(1.dp, ColAccent)) {
                Text(action, color = ColAccent)
            }
        }
    }
}

@Composable
fun TextDialog(
    title: String, label: String, initial: String = "", singleLine: Boolean = true,
    confirm: String = "Save", onDismiss: () -> Unit, onConfirm: (String) -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text, onValueChange = { text = it }, label = { Text(label) },
                singleLine = singleLine, minLines = if (singleLine) 1 else 5
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(text) }) { Text(confirm, color = ColAccent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        containerColor = ColCardHi
    )
}

/** Prominent disclosure shown before sending the user to Accessibility settings. */
@Composable
fun DisclosureDialog(onDismiss: () -> Unit, onAgree: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Enable accessibility service") },
        text = {
            Text(
                "FF KeyMaster uses Android's Accessibility API for two things only:\n\n" +
                    "• Read key presses from your physical keyboard to run your key mappings.\n" +
                    "• Perform taps/holds on the screen at the positions you set.\n\n" +
                    "It does not read screen content, passwords or typed text, and nothing leaves your device. " +
                    "On the next screen, find \"FF KeyMaster\" and turn it on."
            )
        },
        confirmButton = { TextButton(onClick = onAgree) { Text("Continue", color = ColAccent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Not now") } },
        containerColor = ColCardHi
    )
}

/** Increments every time the app returns to the foreground, to re-check system state. */
@Composable
fun rememberResumeTick(): Int {
    val owner = LocalLifecycleOwner.current
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return tick
}
