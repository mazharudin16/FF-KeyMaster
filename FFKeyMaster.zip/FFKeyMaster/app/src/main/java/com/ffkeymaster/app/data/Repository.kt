package com.ffkeymaster.app.data

import android.content.Context
import android.content.SharedPreferences
import android.view.KeyEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class ActionType { TAP, HOLD }

data class KeyMapping(
    val id: String = UUID.randomUUID().toString(),
    val keyCode: Int,
    val name: String,
    /** Position on screen as a fraction (0..1) of the landscape width/height. */
    val x: Float,
    val y: Float,
    val type: ActionType = ActionType.TAP
)

data class Profile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val mappings: List<KeyMapping> = emptyList()
)

data class AppSettings(
    val mapperEnabled: Boolean = true,
    val onlyInGame: Boolean = true,
    val vibrate: Boolean = true,
    val tapMs: Int = 40
)

data class AppData(
    val profiles: List<Profile>,
    val activeId: String,
    val settings: AppSettings = AppSettings()
) {
    val active: Profile get() = profiles.firstOrNull { it.id == activeId } ?: profiles.first()
}

fun keyName(code: Int): String = KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")

object Repository {
    val GAME_PACKAGES = setOf("com.dts.freefireth", "com.dts.freefiremax")

    private var prefs: SharedPreferences? = null
    private val _data = MutableStateFlow(fresh())
    val data: StateFlow<AppData> = _data.asStateFlow()

    fun init(ctx: Context) {
        if (prefs != null) return
        prefs = ctx.applicationContext.getSharedPreferences("ffkeymaster", Context.MODE_PRIVATE)
        _data.value = load()
    }

    // ---- Profiles ----
    fun setActive(id: String) = edit { it.copy(activeId = id) }

    fun addProfile(name: String) = edit {
        val p = Profile(name = name.ifBlank { "New profile" })
        it.copy(profiles = it.profiles + p, activeId = p.id)
    }

    fun duplicateProfile(id: String) = edit { d ->
        val src = d.profiles.firstOrNull { it.id == id } ?: return@edit d
        val copy = Profile(
            name = src.name + " copy",
            mappings = src.mappings.map { it.copy(id = UUID.randomUUID().toString()) }
        )
        d.copy(profiles = d.profiles + copy, activeId = copy.id)
    }

    fun renameProfile(id: String, name: String) =
        mapProfile(id) { it.copy(name = name.ifBlank { it.name }) }

    fun deleteProfile(id: String) = edit { d ->
        if (d.profiles.size <= 1) return@edit d
        val rest = d.profiles.filter { it.id != id }
        d.copy(profiles = rest, activeId = if (d.activeId == id) rest.first().id else d.activeId)
    }

    // ---- Mappings ----
    fun saveMapping(profileId: String, m: KeyMapping) = mapProfile(profileId) { p ->
        // one action per key: drop any other mapping that uses the same key
        val others = p.mappings.filter { it.keyCode != m.keyCode || it.id == m.id }
        val exists = others.any { it.id == m.id }
        p.copy(mappings = if (exists) others.map { if (it.id == m.id) m else it } else others + m)
    }

    fun deleteMapping(profileId: String, mappingId: String) =
        mapProfile(profileId) { p -> p.copy(mappings = p.mappings.filter { it.id != mappingId }) }

    fun moveMapping(profileId: String, mappingId: String, x: Float, y: Float) =
        mapProfile(profileId) { p ->
            p.copy(mappings = p.mappings.map { if (it.id == mappingId) it.copy(x = x, y = y) else it })
        }

    // ---- Settings ----
    fun updateSettings(f: (AppSettings) -> AppSettings) = edit { it.copy(settings = f(it.settings)) }

    fun resetAll() = edit { fresh() }

    // ---- Import / export ----
    fun exportProfile(p: Profile): String = profileToJson(p).put("app", "FFKeyMaster").toString(2)

    fun importProfile(json: String): Boolean = runCatching {
        val p = jsonToProfile(JSONObject(json.trim())).copy(id = UUID.randomUUID().toString())
        edit { it.copy(profiles = it.profiles + p, activeId = p.id) }
        true
    }.getOrDefault(false)

    // ---- Internals ----
    private fun mapProfile(id: String, f: (Profile) -> Profile) = edit { d ->
        d.copy(profiles = d.profiles.map { if (it.id == id) f(it) else it })
    }

    private fun edit(f: (AppData) -> AppData) {
        _data.update(f)
        prefs?.edit()?.putString("data", toJson(_data.value).toString())?.apply()
    }

    private fun defaultProfile() = Profile(
        name = "Default",
        mappings = listOf(
            KeyMapping(keyCode = KeyEvent.KEYCODE_F, name = "Fire", x = 0.84f, y = 0.55f, type = ActionType.HOLD),
            KeyMapping(keyCode = KeyEvent.KEYCODE_SPACE, name = "Jump", x = 0.92f, y = 0.66f),
            KeyMapping(keyCode = KeyEvent.KEYCODE_R, name = "Reload", x = 0.76f, y = 0.82f),
            KeyMapping(keyCode = KeyEvent.KEYCODE_C, name = "Crouch", x = 0.90f, y = 0.84f)
        )
    )

    private fun fresh(): AppData {
        val p = defaultProfile()
        return AppData(listOf(p), p.id)
    }

    private fun load(): AppData {
        val s = prefs?.getString("data", null) ?: return fresh()
        return runCatching {
            val o = JSONObject(s)
            val arr = o.getJSONArray("profiles")
            val profiles = List(arr.length()) { jsonToProfile(arr.getJSONObject(it)) }
            val st = o.getJSONObject("settings")
            val defaults = AppSettings()
            AppData(
                profiles.ifEmpty { listOf(defaultProfile()) },
                o.optString("active"),
                AppSettings(
                    st.optBoolean("enabled", defaults.mapperEnabled),
                    st.optBoolean("onlyInGame", defaults.onlyInGame),
                    st.optBoolean("vibrate", defaults.vibrate),
                    st.optInt("tapMs", defaults.tapMs)
                )
            )
        }.getOrElse { fresh() }
    }

    private fun toJson(d: AppData) = JSONObject()
        .put("active", d.activeId)
        .put("profiles", JSONArray().also { a -> d.profiles.forEach { a.put(profileToJson(it)) } })
        .put(
            "settings", JSONObject()
                .put("enabled", d.settings.mapperEnabled)
                .put("onlyInGame", d.settings.onlyInGame)
                .put("vibrate", d.settings.vibrate)
                .put("tapMs", d.settings.tapMs)
        )

    private fun profileToJson(p: Profile) = JSONObject()
        .put("id", p.id)
        .put("name", p.name)
        .put("mappings", JSONArray().also { a ->
            p.mappings.forEach {
                a.put(
                    JSONObject().put("id", it.id).put("key", it.keyCode).put("name", it.name)
                        .put("x", it.x.toDouble()).put("y", it.y.toDouble()).put("type", it.type.name)
                )
            }
        })

    private fun jsonToProfile(o: JSONObject): Profile {
        val arr = o.getJSONArray("mappings")
        return Profile(
            id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
            name = o.getString("name"),
            mappings = List(arr.length()) {
                val m = arr.getJSONObject(it)
                KeyMapping(
                    id = m.optString("id").ifBlank { UUID.randomUUID().toString() },
                    keyCode = m.getInt("key"),
                    name = m.optString("name"),
                    x = m.getDouble("x").toFloat().coerceIn(0f, 1f),
                    y = m.getDouble("y").toFloat().coerceIn(0f, 1f),
                    type = runCatching { ActionType.valueOf(m.optString("type")) }.getOrDefault(ActionType.TAP)
                )
            }
        )
    }
}
