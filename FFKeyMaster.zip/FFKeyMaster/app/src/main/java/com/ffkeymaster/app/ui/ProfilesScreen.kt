package com.ffkeymaster.app.ui

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ffkeymaster.app.data.AppData
import com.ffkeymaster.app.data.Profile
import com.ffkeymaster.app.data.Repository

@Composable
fun ProfilesScreen(data: AppData) {
    val ctx = LocalContext.current
    var newDialog by remember { mutableStateOf(false) }
    var importDialog by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf<Profile?>(null) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenHeader("Profiles", "Save different setups and switch between them instantly.") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { newDialog = true }, Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = ColAccent, contentColor = androidx.compose.ui.graphics.Color.Black)
                ) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(6.dp)); Text("New") }
                OutlinedButton(onClick = { importDialog = true }, Modifier.weight(1f)) {
                    Icon(Icons.Filled.Download, null); Spacer(Modifier.width(6.dp)); Text("Import")
                }
            }
        }
        items(data.profiles, key = { it.id }) { p ->
            val active = p.id == data.activeId
            val shape = RoundedCornerShape(16.dp)
            Column(
                Modifier.fillMaxWidth().clip(shape).background(ColCard)
                    .border(if (active) 2.dp else 1.dp, if (active) ColAccent else ColLine, shape).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, color = ColText, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Sub("${p.mappings.size} keys")
                    }
                    if (active) Text("ACTIVE", color = ColAccent, fontWeight = FontWeight.Black)
                    else TextButton(onClick = { Repository.setActive(p.id) }) { Text("Load", color = ColCyan) }
                }
                Row {
                    IconButton(onClick = { rename = p }) { Icon(Icons.Filled.Edit, "Rename", tint = ColMuted) }
                    IconButton(onClick = { Repository.duplicateProfile(p.id) }) { Icon(Icons.Filled.ContentCopy, "Duplicate", tint = ColMuted) }
                    IconButton(onClick = {
                        val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                            .putExtra(Intent.EXTRA_SUBJECT, "FF KeyMaster profile: ${p.name}")
                            .putExtra(Intent.EXTRA_TEXT, Repository.exportProfile(p))
                        ctx.startActivity(Intent.createChooser(send, "Share profile"))
                    }) { Icon(Icons.Filled.Share, "Share", tint = ColMuted) }
                    Spacer(Modifier.weight(1f))
                    IconButton(
                        enabled = data.profiles.size > 1,
                        onClick = { Repository.deleteProfile(p.id) }
                    ) { Icon(Icons.Filled.Delete, "Delete", tint = if (data.profiles.size > 1) ColBad else ColLine) }
                }
            }
        }
    }

    if (newDialog) TextDialog("New profile", "Profile name", confirm = "Create",
        onDismiss = { newDialog = false }) { Repository.addProfile(it); newDialog = false }

    rename?.let { p ->
        TextDialog("Rename profile", "Profile name", initial = p.name,
            onDismiss = { rename = null }) { Repository.renameProfile(p.id, it); rename = null }
    }

    if (importDialog) TextDialog("Import profile", "Paste profile JSON", singleLine = false, confirm = "Import",
        onDismiss = { importDialog = false }) {
        val ok = Repository.importProfile(it)
        Toast.makeText(ctx, if (ok) "Profile imported" else "Invalid profile data", Toast.LENGTH_SHORT).show()
        if (ok) importDialog = false
    }
}
