package com.ffkeymaster.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.DisplayMetrics
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import com.ffkeymaster.app.data.ActionType
import com.ffkeymaster.app.data.AppSettings
import com.ffkeymaster.app.data.KeyMapping
import com.ffkeymaster.app.data.Repository
import kotlin.math.max
import kotlin.math.min

/**
 * Intercepts physical keyboard events and turns mapped keys into touch gestures.
 * Only runs while the user has enabled it in Android Accessibility settings.
 */
class KeyMapperService : AccessibilityService() {

    private class Hold(val stroke: StrokeDescription, val path: Path) {
        var ready = false
        var releaseRequested = false
    }

    private val holds = HashMap<Int, Hold>()
    private var currentPackage = ""
    private val vibrator by lazy { getSystemService(Vibrator::class.java) }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Repository.init(this)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        holds.clear()
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {
        holds.clear()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        // ignore keyboards / system overlays so the "current app" stays the game
        if (pkg.contains("inputmethod") || pkg == "com.android.systemui") return
        currentPackage = pkg
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val data = Repository.data.value
        val s = data.settings
        if (!s.mapperEnabled) return false
        if (currentPackage == packageName) return false // never intercept inside our own app
        if (s.onlyInGame && currentPackage !in Repository.GAME_PACKAGES) return false

        val mapping = data.active.mappings.firstOrNull { it.keyCode == event.keyCode } ?: return false
        when (event.action) {
            KeyEvent.ACTION_DOWN -> if (event.repeatCount == 0) press(mapping, s)
            KeyEvent.ACTION_UP -> release(mapping)
        }
        return true // consume: the game never sees the raw key
    }

    private fun press(m: KeyMapping, s: AppSettings) {
        val path = pointPath(m)
        if (s.vibrate) buzz()
        if (m.type == ActionType.TAP) {
            dispatchGesture(build(StrokeDescription(path, 0, s.tapMs.toLong())), null, null)
            return
        }
        if (holds.containsKey(m.keyCode)) return
        val stroke = StrokeDescription(path, 0, HOLD_STEP, true)
        val hold = Hold(stroke, path)
        holds[m.keyCode] = hold
        dispatchGesture(build(stroke), object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                hold.ready = true
                if (hold.releaseRequested) finishHold(m.keyCode, hold)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                holds.remove(m.keyCode)
            }
        }, null)
    }

    private fun release(m: KeyMapping) {
        if (m.type != ActionType.HOLD) return
        val hold = holds[m.keyCode] ?: return
        if (hold.ready) finishHold(m.keyCode, hold) else hold.releaseRequested = true
    }

    private fun finishHold(code: Int, hold: Hold) {
        if (holds.remove(code) == null) return
        val end = hold.stroke.continueStroke(hold.path, 0, HOLD_STEP, false)
        dispatchGesture(build(end), null, null)
    }

    private fun build(stroke: StrokeDescription) =
        GestureDescription.Builder().addStroke(stroke).build()

    private fun pointPath(m: KeyMapping): Path {
        val (w, h) = screenSize()
        return Path().apply { moveTo(m.x * w, m.y * h) }
    }

    /** Layouts are authored for landscape, so use the long edge as width. */
    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(WindowManager::class.java)
        val (a, b) = if (Build.VERSION.SDK_INT >= 30) {
            val r = wm.maximumWindowMetrics.bounds
            r.width() to r.height()
        } else {
            val dm = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
        return max(a, b) to min(a, b)
    }

    @Suppress("DEPRECATION")
    private fun buzz() {
        runCatching {
            vibrator?.vibrate(VibrationEffect.createOneShot(15, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    private companion object {
        const val HOLD_STEP = 50L
    }
}
