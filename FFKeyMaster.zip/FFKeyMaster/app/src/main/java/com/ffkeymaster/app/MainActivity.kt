package com.ffkeymaster.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ffkeymaster.app.data.Repository
import com.ffkeymaster.app.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { FFTheme { App() } }
    }
}

private data class Tab(val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("Home", Icons.Filled.SportsEsports),
    Tab("Keys", Icons.Filled.Keyboard),
    Tab("Layout", Icons.Filled.GridView),
    Tab("Profiles", Icons.Filled.Person),
    Tab("Settings", Icons.Filled.Settings)
)

@Composable
private fun App() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val data by Repository.data.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = ColBg,
        bottomBar = {
            NavigationBar(containerColor = ColCard) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = ColAccent,
                            indicatorColor = ColAccent,
                            unselectedIconColor = ColMuted,
                            unselectedTextColor = ColMuted
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> DashboardScreen(data, onNavigate = { tab = it })
                1 -> KeysScreen(data)
                2 -> LayoutScreen(data)
                3 -> ProfilesScreen(data)
                else -> SettingsScreen(data)
            }
        }
    }
}
