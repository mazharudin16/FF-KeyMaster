package com.ffkeymaster.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ColBg = Color(0xFF0B0E14)
val ColCard = Color(0xFF141922)
val ColCardHi = Color(0xFF1C2330)
val ColLine = Color(0xFF2A3342)
val ColAccent = Color(0xFFFF6A00)
val ColCyan = Color(0xFF00E5FF)
val ColGood = Color(0xFF39D98A)
val ColBad = Color(0xFFFF4D5E)
val ColText = Color(0xFFE8ECF3)
val ColMuted = Color(0xFF9AA4B5)

private val scheme = darkColorScheme(
    primary = ColAccent, onPrimary = Color.Black,
    secondary = ColCyan, onSecondary = Color.Black,
    background = ColBg, onBackground = ColText,
    surface = ColCard, onSurface = ColText,
    surfaceVariant = ColCardHi, onSurfaceVariant = ColMuted,
    error = ColBad, outline = ColLine
)

@Composable
fun FFTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = scheme, content = content)
