package com.ffkeymaster.app.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffkeymaster.app.data.AppData
import com.ffkeymaster.app.data.Repository
import com.ffkeymaster.app.util.SystemChecks

@Composable
fun DashboardScreen(data: AppData, onNavigate: (Int) -> Unit) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val svc = remember(tick) { SystemChecks.accessibilityEnabled(ctx) }
    val kb = remember(tick) { SystemChecks.hasKeyboard() }
    val batt = remember(tick) { SystemChecks.batteryUnrestricted(ctx) }
    var disclosure by remember { mutableStateOf(false) }

    val s = data.settings
    val (status, color) = when {
        !svc -> "SETUP REQUIRED" to ColBad
        !s.mapperEnabled -> "STANDBY" to ColMuted
        else -> "ARMED" to ColGood
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        val shape = RoundedCornerShape(20.dp)
        Column(
            Modifier.fillMaxWidth().clip(shape)
                .background(Brush.linearGradient(listOf(Color(0xFF3A1A00), ColCard)))
                .border(1.dp, ColAccent.copy(alpha = .5f), shape).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("FF KEYMASTER", color = ColAccent, fontWeight = FontWeight.Black, fontSize = 26.sp, letterSpacing = 3.sp)
            Text(status, color = color, fontWeight = FontWeight.Bold, fontSize = 18.sp, letterSpacing = 2.sp)
            Sub("Active profile: ${data.active.name}")
            Button(
                onClick = {
                    if (!svc) disclosure = true
                    else Repository.updateSettings { it.copy(mapperEnabled = !it.mapperEnabled) }
                },
                colors = ButtonDefaults.buttonColors(containerColor = if (s.mapperEnabled && svc) ColAccent else ColCardHi,
                    contentColor = if (s.mapperEnabled && svc) Color.Black else ColText),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Icon(Icons.Filled.PowerSettingsNew, null)
                Spacer(Modifier.width(8.dp))
                Text(if (!svc) "ENABLE SERVICE" else if (s.mapperEnabled) "MAPPER ON" else "MAPPER OFF", fontWeight = FontWeight.Bold)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Stat("Keys", data.active.mappings.size.toString(), Modifier.weight(1f))
            Stat("Profiles", data.profiles.size.toString(), Modifier.weight(1f))
            Stat("Tap", "${s.tapMs} ms", Modifier.weight(1f))
        }

        Panel {
            Title("System status")
            StatusRow("Accessibility service",
                if (svc) "Running — key mapping available" else "Required to read keys and perform taps",
                svc, "Enable") { disclosure = true }
            StatusRow("Physical keyboard",
                if (kb) "Keyboard detected" else "Connect a USB / Bluetooth keyboard",
                kb, null) {}
            StatusRow("Background reliability",
                if (batt) "Battery optimization disabled" else "Recommended so Android doesn't stop the service",
                batt, "Allow") { SystemChecks.requestBatteryExemption(ctx) }
        }

        Panel {
            Title("Quick actions")
            Button(
                onClick = {
                    if (!SystemChecks.launchGame(ctx))
                        Toast.makeText(ctx, "Free Fire is not installed", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = ColAccent, contentColor = Color.Black),
                modifier = Modifier.fillMaxWidth()
            ) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("Launch Free Fire") }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { onNavigate(1) }, Modifier.weight(1f)) { Text("Edit keys") }
                OutlinedButton(onClick = { onNavigate(2) }, Modifier.weight(1f)) { Text("Layout") }
                OutlinedButton(onClick = { onNavigate(3) }, Modifier.weight(1f)) { Text("Profiles") }
            }
        }
    }

    if (disclosure) DisclosureDialog(
        onDismiss = { disclosure = false },
        onAgree = { disclosure = false; SystemChecks.openAccessibilitySettings(ctx) }
    )
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier.clip(shape).background(ColCard).border(1.dp, ColLine, shape).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, color = ColCyan, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Sub(label)
    }
}
