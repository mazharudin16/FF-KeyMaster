package com.ffkeymaster.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffkeymaster.app.data.*
import kotlin.math.roundToInt

@Composable
fun LayoutScreen(data: AppData) {
    val profile = data.active
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    val selected = profile.mappings.firstOrNull { it.id == selectedId }
    val shape = RoundedCornerShape(16.dp)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenHeader("Control layout", "Drag each key onto the matching on-screen button in your game (landscape). Profile: ${profile.name}")

        Box(
            Modifier.fillMaxWidth().aspectRatio(20f / 9f).clip(shape).background(ColBg)
                .border(1.dp, ColLine, shape).onSizeChanged { boxSize = it }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                for (i in 1..9) drawLine(ColLine, Offset(i * size.width / 10, 0f), Offset(i * size.width / 10, size.height))
                for (i in 1..3) drawLine(ColLine, Offset(0f, i * size.height / 4), Offset(size.width, i * size.height / 4))
            }
            if (boxSize.width > 0) profile.mappings.forEach { m ->
                key(m.id) {
                    DragKey(m, boxSize, m.id == selectedId,
                        onSelect = { selectedId = m.id },
                        onCommit = { nx, ny -> Repository.moveMapping(profile.id, m.id, nx, ny) })
                }
            }
        }

        Panel {
            if (selected == null) {
                Title("Tip")
                Sub("Tap or drag a key to select it. Positions are saved automatically to the active profile.")
            } else {
                Title("${keyName(selected.keyCode)} → ${selected.name.ifBlank { "Unnamed" }}")
                Sub("${selected.type.name} • X ${(selected.x * 100).roundToInt()}%  Y ${(selected.y * 100).roundToInt()}%")
                OutlinedButton(onClick = { Repository.moveMapping(profile.id, selected.id, 0.5f, 0.5f) }) {
                    Text("Center this key")
                }
            }
        }
    }
}

@Composable
private fun DragKey(
    m: KeyMapping, boxSize: IntSize, selected: Boolean,
    onSelect: () -> Unit, onCommit: (Float, Float) -> Unit
) {
    val w = boxSize.width.toFloat()
    val h = boxSize.height.toFloat()
    val r = with(LocalDensity.current) { 22.dp.toPx() }
    val cur by rememberUpdatedState(m)
    val commit by rememberUpdatedState(onCommit)
    var off by remember { mutableStateOf(Offset.Zero) }
    var dragging by remember { mutableStateOf(false) }
    val pos = if (dragging) off else Offset(m.x * w, m.y * h)

    Box(
        Modifier
            .offset { IntOffset((pos.x - r).roundToInt(), (pos.y - r).roundToInt()) }
            .size(44.dp).clip(CircleShape)
            .background(if (selected) ColAccent else ColAccent.copy(alpha = .25f))
            .border(2.dp, ColAccent, CircleShape)
            .pointerInput(Unit) { detectTapGestures { onSelect() } }
            .pointerInput(boxSize) {
                detectDragGestures(
                    onDragStart = { dragging = true; off = Offset(cur.x * w, cur.y * h); onSelect() },
                    onDragEnd = {
                        dragging = false
                        commit((off.x / w).coerceIn(0f, 1f), (off.y / h).coerceIn(0f, 1f))
                    },
                    onDragCancel = { dragging = false }
                ) { change, amount -> change.consume(); off += amount }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            keyName(m.keyCode).take(5), fontSize = 10.sp, fontWeight = FontWeight.Bold,
            color = if (selected) Color.Black else Color.White, maxLines = 1
        )
    }
}
