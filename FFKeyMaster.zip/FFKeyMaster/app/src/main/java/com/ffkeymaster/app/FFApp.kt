package com.ffkeymaster.app

import android.app.Application
import com.ffkeymaster.app.data.Repository

class FFApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Repository.init(this)
    }
}
